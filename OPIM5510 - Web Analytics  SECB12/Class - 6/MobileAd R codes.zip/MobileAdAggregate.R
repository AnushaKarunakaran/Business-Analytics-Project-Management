# import data from MobileAdAggregate.xlsx
# if the commands below do not work for you, use "Import Dataset" button on the right
install.packages(readxl)
library(readxl)
MobileAdAggregate <- read_excel("MobileAdAggregate.xlsx")
View(MobileAdAggregate)

#basic statistics
hist(MobileAdAggregate$Purchases,breaks=20)
mean(MobileAdAggregate$Purchases)
var(MobileAdAggregate$Purchases)

#negative binomial regression
library(MASS)
summary(nml<-glm(Purchases~Sunny+Rainy+AdVersion+as.factor(Location), 
         family=negative.binomial(1), data=MobileAdAggregate,
         control=glm.control(maxit=500)))
summary(nml2<-glm(Purchases~Sunny+Rainy+AdVersion+as.factor(Location)
          +Sunny:AdVersion+Rainy:AdVersion, 
         family=negative.binomial(1), data=MobileAdAggregate,
         control=glm.control(maxit=500)))

# test sunny effect and rainy effet for Ad version with prevention framing
install.packages("car")
library("car")
linearHypothesis(nml2,"Sunny+Sunny:AdVersion=0")
linearHypothesis(nml2,"Rainy+Rainy:AdVersion=0")

# compare sunny effect and rainy effect for ad version without prevention framing
linearHypothesis(nml2,"Sunny=Rainy")

# compare sunny effect and rainy effect for ad version with prevention framing
linearHypothesis(nml2,"Sunny+Sunny:AdVersion=Rainy+Rainy:AdVersion")

#linear and Poisson regressions
summary(ml<-lm(Purchases~Sunny+Rainy+AdVersion+as.factor(Location),
       MobileAdAggregate))
summary(pl<-glm(Purchases~Sunny+Rainy+AdVersion+as.factor(Location), 
          family="poisson", data=MobileAdAggregate))

#compare regressions
install.packages("lmtest")
library("lmtest")
lrtest(pl,nml)
lrtest(ml,nml)

#fit Y into different distributions
install.packages("fitdistrplus")
library("fitdistrplus")

plot(fit.pois<-fitdist(MobileAdAggregate$Purchases, "norm"))
plot(fit.pois<-fitdist(MobileAdAggregate$Purchases, "pois"))
plot(fit.nbinom<-fitdist(MobileAdAggregate$Purchases, "nbinom"))

# remove data
rm(MobileAdAggregate)
