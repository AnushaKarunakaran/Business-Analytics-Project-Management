# import data from MobileAd.xls
# if the commands below do not work for you, use "Import Dataset" button on the right
install.packages(readxl)
library(readxl)
MobileAd <- read_excel("MobileAd.xls")
View(MobileAd)

# examine main weather effect
summary(ml<-glm(Responded~Sunny+Rainy+AdVersion+as.factor(Location),family=binomial("logit"),
        data=MobileAd))

# examine interaction effects
summary(iml<-glm(Responded~Sunny+Rainy+AdVersion+Sunny:AdVersion+Rainy:AdVersion+as.factor(Location),
        family=binomial("logit"),data=MobileAd))

# test sunny effect and rainy effet for Ad version with prevention framing
install.packages("car")
library("car")

linearHypothesis(iml,"Sunny+Sunny:AdVersion=0")
linearHypothesis(iml,"Rainy+Rainy:AdVersion=0")

# compare sunny effect and rainy effect for ad version without prevention framing
linearHypothesis(iml,"Sunny=Rainy")

# compare sunny effect and rainy effect for ad version with prevention framing
linearHypothesis(iml,"Sunny+Sunny:AdVersion=Rainy+Rainy:AdVersion")

# remove data
rm(MobileAd)
rm(ml)
rm(iml)
