# first import data
# if the command does not work for you, use Import Dataset button on the right
library(readxl)
DID <- read_excel("DID.xlsx")
View(DID)

# DID analysis
summary(ml<-lm(sales~as.factor(after)+as.factor(treated)+as.factor(treated):as.factor(after), data=DID))

# check parallel trend assumption
summary(iml<-lm(sales~as.factor(treated)+as.factor(period)+as.factor(treated):as.factor(period), data=DID))

# install packages needed to draw the parallel trend graph
install.packages("coefplot")
library("ggplot2")
library("coefplot")

# draw the parallel trend graph
coefplot(iml, predictors="as.factor(treated):as.factor(period)", horizontal=FALSE,
         title="", ylab=" ", xlab="")

#remove data
rm(DID)
rm(iml)
rm(ml)