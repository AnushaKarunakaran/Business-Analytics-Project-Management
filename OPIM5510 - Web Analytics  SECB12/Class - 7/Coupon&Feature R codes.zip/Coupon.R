# import data from Coupon.xlsx
# if command does not work, use "import dataset" button on the right
library(readxl)
Coupon <- read_excel("Coupon.xlsx")
View(Coupon)

# install package to run conditional logit model
install.packages("survival")
library("survival")

# conditional logit model
summary(cml<-clogit(purchased ~ review_val + review_vol + coupon + price_level 
                    + coupon_prone:coupon + strata(browse_id), data=Coupon))

# install package to do linear hypothesis testing
install.packages("car")
library("car")

# test the coupon effect for consumers whose coupon proneness equals 1
linearHypothesis(cml,"coupon+coupon:coupon_prone=0")

# test the coupon effect for consumers whose coupon proneness equals 0.5
linearHypothesis(cml,"coupon+0.5*coupon:coupon_prone=0")

# remove data
rm(Coupon)
rm(cml)
