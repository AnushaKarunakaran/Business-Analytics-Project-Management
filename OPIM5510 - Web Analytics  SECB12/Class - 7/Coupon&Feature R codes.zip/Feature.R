# import data from Feature.xlsx
# if command does not work, use "import dataset" button on the right
library(readxl)
feature <- read_excel("Feature.xlsx")
View(feature)

# does product feature affect product sales?
summary(ml<-lm(Sales~Feature+Age+Price,data=feature))

# check balance between products from control and treatment
summary(lm(Age~Feature, data=feature))
summary(lm(Price~Feature, data=feature))

# install package to do PSM
install.packages("MatchIt")
library("MatchIt")

# estimate propensity score
summary(psm <- matchit(Feature~Age+Price, data=feature, method = "nearest", ratio=1, distance='logit', caliper=0.0001))
## distance specifies the method used to estimate the distance measure (logit in this case)
## nearest specifies the matching method (nearest neighbor in this case)
## ratio specifies the number of control units to match to each treated unit (one-to-one matching in this case)
## caliper specifies the standard deviation of the distance measure within which to draw control units 
## If more than the required number of control units are matched, 
## the control units within the caliper for a treated unit are randomly selected as the match for that treated unit

# copy data to data_psm, add match indicator (weights) to the data, and remove unmatched observations
data_psm=subset(cbind(feature,weights=psm$weights),weights==1)
View(data_psm)

# check balance between products from control and treatment after match
summary(lm(Age~Feature, data=data_psm))
summary(lm(Price~Feature, data=data_psm))

# re-run regression with matched observations
summary(ml_psm<-lm(Sales~Feature+Age+Price,data=data_psm))

# remove data
rm(feature)
rm(data_psm)
rm(ml)
rm(psm)
rm(ml_psm)