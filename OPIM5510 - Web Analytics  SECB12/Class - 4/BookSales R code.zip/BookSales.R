# first import BookSales data into R
# if the commands below do not work for you, you can also use "Import Dataset" button on the right
install.packages(readxl)
library(readxl)
BookSales <- read_excel("BookSales.xlsx")
View(BookSales)

# load dataset for analysis
attach(BookSales)

# regression analysis
ml1<-lm(sales ~ quality)
summary(ml1)
ml2<-lm(sales ~ price)
summary(ml2)
ml3<-lm(sales ~ price + quality)
summary(ml3)
ml4<-lm(price ~ quality)
summary(ml4)
ml5<-lm(sales ~ price + quality + as.factor(channel))
summary(ml5)

# install package "car" if you don't have it
install.packages("car")
# load package "car"
library("car")

# compare channel 2 and channel 3
linearHypothesis(ml5,"as.factor(channel)2 = as.factor(channel)3")

ml6<-lm(sales ~ price + quality + as.factor(channel) + price:as.factor(channel) + quality:as.factor(channel))
summary(ml6)

# compare price effect between channel 2 and channel 3
linearHypothesis(ml6,"price:as.factor(channel)2 = price:as.factor(channel)3")

#unload data
detach(BookSales)

#remove BookSales data
rm(BookSales)
